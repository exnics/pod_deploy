#!/bin/bash

# Creates the folders and groups
# used by the exnics application.
#
# After running add users to the group that
# need access.

# Add exnics group if it doesn't exist.
/usr/bin/getent group exnics 2>&1 > /dev/null || /usr/sbin/groupadd exnics

dirs_to_create='/var/log/exnics /var/log/exnics_data /etc/exnics'

for dir in $dirs_to_create
do
  echo "Creating $dir"
  mkdir -p $dir
  chgrp exnics $dir
  chmod 775 $dir
done
